import 'package:flutter/material.dart';

void main() {
  runApp(const VibeSpaceApp());
}

const navy = Color(0xFF172554);
const blue = Color(0xFF2563EB);
const purple = Color(0xFF7C3AED);
const pale = Color(0xFFF5F7FF);

class VibeSpaceApp extends StatelessWidget {
  const VibeSpaceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VibeSpace',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pale,
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 17),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE1E7F5)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE1E7F5)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: blue, width: 1.6),
          ),
        ),
      ),
      home: const WelcomePage(),
    );
  }
}

class BrandMark extends StatelessWidget {
  const BrandMark({super.key, this.size = 76});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * .28),
        gradient: const LinearGradient(
          colors: [blue, purple],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: purple.withOpacity(.22),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Icon(Icons.forum_rounded, color: Colors.white, size: size * .52),
    );
  }
}

class GradientButton extends StatelessWidget {
  const GradientButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
  });

  final String label;
  final VoidCallback onPressed;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: const LinearGradient(colors: [blue, purple]),
        ),
        child: ElevatedButton.icon(
          onPressed: onPressed,
          icon: icon == null ? const SizedBox.shrink() : Icon(icon),
          label: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            foregroundColor: Colors.white,
            shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
        ),
      ),
    );
  }
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const BrandMark(size: 94),
                  const SizedBox(height: 24),
                  const Text(
                    'VibeSpace',
                    style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: navy, letterSpacing: -.8),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Connect. Create. Share. Earn.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, color: Color(0xFF667085), fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 38),
                  const _FeatureChip(icon: Icons.video_collection_rounded, text: 'Videos, photos and stories'),
                  const SizedBox(height: 12),
                  const _FeatureChip(icon: Icons.people_alt_rounded, text: 'Find people and build community'),
                  const SizedBox(height: 12),
                  const _FeatureChip(icon: Icons.stars_rounded, text: 'Creator tools and rewards'),
                  const SizedBox(height: 42),
                  GradientButton(
                    label: 'CREATE ACCOUNT',
                    icon: Icons.person_add_alt_1_rounded,
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: OutlinedButton(
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: navy,
                        side: const BorderSide(color: Color(0xFFD8DFF0)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        backgroundColor: Colors.white,
                      ),
                      child: const Text('LOG IN', style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'By continuing, you agree to follow our community guidelines.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Color(0xFF98A2B3), fontSize: 11),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _FeatureChip extends StatelessWidget {
  const _FeatureChip({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
      child: Row(
        children: [
          Icon(icon, color: purple, size: 21),
          const SizedBox(width: 12),
          Text(text, style: const TextStyle(color: navy, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _username = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _hidePassword = true;
  bool _accepted = false;

  @override
  void dispose() {
    _name.dispose();
    _username.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  String? requiredField(String? value, String label) =>
      value == null || value.trim().isEmpty ? 'Enter your $label' : null;

  void _createAccount() {
    if (!_formKey.currentState!.validate()) return;
    if (!_accepted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please accept the Terms and Community Guidelines to continue.')),
      );
      return;
    }
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Registration form complete'),
        content: const Text(
          'Your details passed the basic form checks. Account creation is not connected to a secure server yet. The next step is to connect authentication and email/phone verification.',
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: pale, title: const Text('Create account', style: TextStyle(color: navy, fontWeight: FontWeight.w800))),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 30),
                children: [
                  const BrandMark(size: 58),
                  const SizedBox(height: 18),
                  const Text('Join VibeSpace', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: navy)),
                  const SizedBox(height: 6),
                  const Text('Create your account and start connecting.', style: TextStyle(color: Color(0xFF667085))),
                  const SizedBox(height: 26),
                  const _FieldLabel('Full name'),
                  TextFormField(controller: _name, textCapitalization: TextCapitalization.words, validator: (v) => requiredField(v, 'full name'), decoration: const InputDecoration(hintText: 'Enter your full name')),
                  const SizedBox(height: 17),
                  const _FieldLabel('Username'),
                  TextFormField(
                    controller: _username,
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) return 'Choose a username';
                      if (!RegExp(r'^[a-zA-Z0-9_]{3,20}$').hasMatch(v.trim())) return 'Use 3–20 letters, numbers or underscores';
                      return null;
                    },
                    decoration: const InputDecoration(prefixText: '@', hintText: 'Choose a username'),
                  ),
                  const SizedBox(height: 17),
                  const _FieldLabel('Email address'),
                  TextFormField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) return 'Enter your email address';
                      if (!RegExp(r'^[^@]+@[^@]+\.[^@]+$').hasMatch(v.trim())) return 'Enter a valid email address';
                      return null;
                    },
                    decoration: const InputDecoration(hintText: 'you@example.com'),
                  ),
                  const SizedBox(height: 17),
                  const _FieldLabel('Password'),
                  TextFormField(
                    controller: _password,
                    obscureText: _hidePassword,
                    validator: (v) => v == null || v.length < 8 ? 'Use at least 8 characters' : null,
                    decoration: InputDecoration(
                      hintText: 'Create a password',
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => _hidePassword = !_hidePassword),
                        icon: Icon(_hidePassword ? Icons.visibility_off : Icons.visibility),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  CheckboxListTile(
                    value: _accepted,
                    onChanged: (v) => setState(() => _accepted = v ?? false),
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    title: const Text('I agree to the Terms and Community Guidelines.', style: TextStyle(fontSize: 13)),
                  ),
                  const SizedBox(height: 14),
                  GradientButton(label: 'CREATE MY ACCOUNT', onPressed: _createAccount),
                  const SizedBox(height: 18),
                  Center(
                    child: TextButton(
                      onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginPage())),
                      child: const Text('Already have an account? Log in'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _email = TextEditingController();
  final _password = TextEditingController();

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: pale, title: const Text('Log in', style: TextStyle(color: navy, fontWeight: FontWeight.w800))),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 460),
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.all(24),
            children: [
              const BrandMark(size: 64),
              const SizedBox(height: 20),
              const Text('Welcome back', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: navy)),
              const SizedBox(height: 20),
              const _FieldLabel('Email address'),
              TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(hintText: 'you@example.com')),
              const SizedBox(height: 17),
              const _FieldLabel('Password'),
              TextField(controller: _password, obscureText: true, decoration: const InputDecoration(hintText: 'Enter your password')),
              const SizedBox(height: 24),
              GradientButton(
                label: 'LOG IN',
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Login will work after secure authentication is connected.')),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(text, style: const TextStyle(color: navy, fontWeight: FontWeight.w700)),
      );
}
