# VibeSpace starter

This is the first Flutter UI milestone for VibeSpace:
- Welcome screen with Create Account and Log In buttons
- Registration form with basic client-side validation
- Login screen placeholder
- Blue, purple and white visual identity
- Flutter targets Android, iOS and web

## Important
This is a UI prototype only. It does NOT yet create real user accounts, store passwords, send verification codes, upload media, or process payments. Do not collect real user passwords with this prototype.

## Run it
1. Install Flutter and set up Android Studio / Xcode as appropriate.
2. Extract this ZIP.
3. In the project folder, run:
   flutter pub get
   flutter run

For web:
   flutter run -d chrome

To generate platform folders if needed:
   flutter create .
