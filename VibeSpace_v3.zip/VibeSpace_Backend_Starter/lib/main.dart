import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const VibeSpaceApp());
}

const blue = Color(0xFF2563EB);
const purple = Color(0xFF7C3AED);
const navy = Color(0xFF172554);
const pale = Color(0xFFF5F7FF);

class VibeSpaceApp extends StatelessWidget {
  const VibeSpaceApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'VibeSpace',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: pale,
          colorScheme: ColorScheme.fromSeed(seedColor: blue),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
        home: const AuthGate(),
      );
}

class BrandMark extends StatelessWidget {
  const BrandMark({super.key, this.size = 60});
  final double size;

  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [blue, purple]),
          borderRadius: BorderRadius.circular(size * .28),
        ),
        child: Icon(Icons.forum_rounded, color: Colors.white, size: size * .52),
      );
}

class GradientButton extends StatelessWidget {
  const GradientButton({super.key, required this.label, required this.onPressed});
  final String label;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        height: 54,
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [blue, purple]),
            borderRadius: BorderRadius.circular(15),
          ),
          child: ElevatedButton(
            onPressed: onPressed,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              foregroundColor: Colors.white,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            ),
            child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        ),
      );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          return snapshot.data == null ? const WelcomePage() : const HomeFeedPage();
        },
      );
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Padding(
                padding: const EdgeInsets.all(26),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const BrandMark(size: 92),
                    const SizedBox(height: 20),
                    const Text('VibeSpace', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: navy)),
                    const SizedBox(height: 7),
                    const Text('Connect. Create. Share. Earn.', style: TextStyle(color: Colors.blueGrey, fontSize: 16)),
                    const SizedBox(height: 36),
                    GradientButton(
                      label: 'CREATE ACCOUNT',
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: OutlinedButton(
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())),
                        child: const Text('LOG IN'),
                      ),
                    ),
                    const SizedBox(height: 22),
                    const Text('A place to connect, create and share.', style: TextStyle(color: Colors.blueGrey)),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final form = GlobalKey<FormState>();
  final name = TextEditingController();
  final username = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  bool accepted = false;
  bool busy = false;
  bool hidePassword = true;

  @override
  void dispose() {
    name.dispose();
    username.dispose();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> register() async {
    if (!form.currentState!.validate()) return;
    if (!accepted) {
      showMessage('Please accept the Terms and Community Guidelines.');
      return;
    }
    setState(() => busy = true);
    try {
      final cleanUsername = username.text.trim().toLowerCase().replaceAll('@', '');
      final userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email.text.trim(),
        password: password.text,
      );
      final uid = userCredential.user!.uid;
      final usernameRef = FirebaseFirestore.instance.collection('usernames').doc(cleanUsername);
      final profileRef = FirebaseFirestore.instance.collection('users').doc(uid);

      await FirebaseFirestore.instance.runTransaction((transaction) async {
        final usernameDoc = await transaction.get(usernameRef);
        if (usernameDoc.exists) {
          throw Exception('That username is already taken. Please choose another.');
        }
        transaction.set(usernameRef, {'uid': uid});
        transaction.set(profileRef, {
          'uid': uid,
          'displayName': name.text.trim(),
          'username': cleanUsername,
          'email': email.text.trim(),
          'bio': '',
          'photoUrl': '',
          'createdAt': FieldValue.serverTimestamp(),
        });
      });
      await userCredential.user!.sendEmailVerification();
      if (mounted) showMessage('Account created. Please check your email for a verification link.');
    } on FirebaseAuthException catch (e) {
      showMessage(authError(e));
    } catch (e) {
      showMessage(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void showMessage(String value) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Create account')),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Form(
              key: form,
              child: ListView(
                padding: const EdgeInsets.all(24),
                children: [
                  const BrandMark(),
                  const SizedBox(height: 15),
                  const Text('Join VibeSpace', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: navy)),
                  const SizedBox(height: 18),
                  TextFormField(
                    controller: name,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(labelText: 'Full name'),
                    validator: (v) => v == null || v.trim().isEmpty ? 'Enter your name' : null,
                  ),
                  const SizedBox(height: 13),
                  TextFormField(
                    controller: username,
                    decoration: const InputDecoration(labelText: 'Username', prefixText: '@'),
                    validator: (v) {
                      final value = (v ?? '').trim().replaceAll('@', '');
                      if (!RegExp(r'^[a-zA-Z0-9_]{3,20}$').hasMatch(value)) {
                        return 'Use 3–20 letters, numbers or underscores';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 13),
                  TextFormField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'Email address'),
                    validator: (v) => v == null || !RegExp(r'^[^@]+@[^@]+\.[^@]+$').hasMatch(v.trim())
                        ? 'Enter a valid email'
                        : null,
                  ),
                  const SizedBox(height: 13),
                  TextFormField(
                    controller: password,
                    obscureText: hidePassword,
                    decoration: InputDecoration(
                      labelText: 'Password (at least 8 characters)',
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => hidePassword = !hidePassword),
                        icon: Icon(hidePassword ? Icons.visibility_off : Icons.visibility),
                      ),
                    ),
                    validator: (v) => v == null || v.length < 8 ? 'Use at least 8 characters' : null,
                  ),
                  CheckboxListTile(
                    value: accepted,
                    onChanged: (v) => setState(() => accepted = v ?? false),
                    contentPadding: EdgeInsets.zero,
                    title: const Text('I agree to the Terms and Community Guidelines', style: TextStyle(fontSize: 13)),
                  ),
                  const SizedBox(height: 10),
                  GradientButton(label: busy ? 'CREATING ACCOUNT…' : 'CREATE MY ACCOUNT', onPressed: busy ? null : register),
                  const SizedBox(height: 8),
                  const Text(
                    'Use a password you do not use on other websites. VibeSpace will never ask you to share it.',
                    style: TextStyle(fontSize: 11, color: Colors.blueGrey),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> login() async {
    setState(() => busy = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email.text.trim(),
        password: password.text,
      );
    } on FirebaseAuthException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(authError(e))));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Log in')),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.all(24),
              children: [
                const BrandMark(),
                const SizedBox(height: 18),
                const Text('Welcome back', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: navy)),
                const SizedBox(height: 18),
                TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email address')),
                const SizedBox(height: 13),
                TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
                const SizedBox(height: 20),
                GradientButton(label: busy ? 'LOGGING IN…' : 'LOG IN', onPressed: busy ? null : login),
              ],
            ),
          ),
        ),
      );
}

class HomeFeedPage extends StatefulWidget {
  const HomeFeedPage({super.key});
  @override
  State<HomeFeedPage> createState() => _HomeFeedPageState();
}

class _HomeFeedPageState extends State<HomeFeedPage> {
  final postController = TextEditingController();
  bool posting = false;

  @override
  void dispose() {
    postController.dispose();
    super.dispose();
  }

  Future<void> createPost() async {
    final text = postController.text.trim();
    if (text.isEmpty) return;
    setState(() => posting = true);
    try {
      final user = FirebaseAuth.instance.currentUser!;
      final profile = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      await FirebaseFirestore.instance.collection('posts').add({
        'uid': user.uid,
        'displayName': profile.data()?['displayName'] ?? 'VibeSpace user',
        'username': profile.data()?['username'] ?? '',
        'text': text,
        'mediaUrl': '',
        'createdAt': FieldValue.serverTimestamp(),
        'likeCount': 0,
      });
      postController.clear();
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not publish post: $e')));
    } finally {
      if (mounted) setState(() => posting = false);
    }
  }

  void openComposer() {
    postController.clear();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(sheetContext).viewInsets.bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Create a post', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: navy)),
            const SizedBox(height: 12),
            TextField(controller: postController, maxLines: 4, decoration: const InputDecoration(hintText: 'What would you like to share?')),
            const SizedBox(height: 12),
            GradientButton(label: posting ? 'POSTING…' : 'POST', onPressed: posting ? null : createPost),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final posts = FirebaseFirestore.instance.collection('posts').orderBy('createdAt', descending: true).limit(50);
    final user = FirebaseAuth.instance.currentUser!;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Row(children: [
          BrandMark(size: 34),
          SizedBox(width: 9),
          Text('VibeSpace', style: TextStyle(color: navy, fontWeight: FontWeight.w900)),
        ]),
        actions: [
          IconButton(
            tooltip: 'Log out',
            onPressed: () => FirebaseAuth.instance.signOut(),
            icon: const Icon(Icons.logout_rounded),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            padding: const EdgeInsets.all(17),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [blue, purple]),
              borderRadius: BorderRadius.circular(17),
            ),
            child: const Text('Your space. Your voice.\nConnect with people and share what matters.', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, height: 1.4)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: openComposer,
                icon: const Icon(Icons.add_circle_outline),
                label: const Text('Create a post'),
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: posts.snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) return Center(child: Text('Feed error: ${snapshot.error}'));
                if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
                final docs = snapshot.data!.docs;
                if (docs.isEmpty) return const Center(child: Text('No posts yet. Be the first to share!'));
                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 20),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final data = docs[index].data();
                    final timestamp = data['createdAt'] as Timestamp?;
                    final dateLabel = timestamp == null ? 'Just now' : timestamp.toDate().toLocal().toString().substring(0, 16);
                    final isMine = data['uid'] == user.uid;
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            const CircleAvatar(backgroundColor: Color(0xFFEDE9FE), child: Icon(Icons.person, color: purple)),
                            const SizedBox(width: 10),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(data['displayName'] ?? 'VibeSpace user', style: const TextStyle(fontWeight: FontWeight.w800, color: navy)),
                              Text('@${data['username'] ?? ''} · $dateLabel', style: const TextStyle(fontSize: 11, color: Colors.blueGrey)),
                            ])),
                            if (isMine)
                              IconButton(
                                tooltip: 'Delete your post',
                                onPressed: () => docs[index].reference.delete(),
                                icon: const Icon(Icons.delete_outline, color: Colors.blueGrey),
                              ),
                          ]),
                          const SizedBox(height: 12),
                          Text(data['text'] ?? '', style: const TextStyle(height: 1.4)),
                          const Divider(height: 22),
                          Row(children: [
                            const Icon(Icons.favorite_border, size: 18, color: purple),
                            const SizedBox(width: 5),
                            Text('${data['likeCount'] ?? 0} likes', style: const TextStyle(color: Colors.blueGrey, fontSize: 12)),
                          ]),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: openComposer,
        backgroundColor: purple,
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
      ),
    );
  }
}

String authError(FirebaseAuthException error) {
  switch (error.code) {
    case 'email-already-in-use':
      return 'An account already uses this email address.';
    case 'invalid-email':
      return 'Please enter a valid email address.';
    case 'weak-password':
      return 'Choose a stronger password.';
    case 'user-not-found':
    case 'wrong-password':
    case 'invalid-credential':
      return 'Email or password is incorrect.';
    case 'network-request-failed':
      return 'Network error. Check your internet connection and try again.';
    default:
      return error.message ?? 'Authentication failed. Please try again.';
  }
}
