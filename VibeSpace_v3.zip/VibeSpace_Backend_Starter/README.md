# VibeSpace — Firebase backend starter (Milestone 3)

This version moves the prototype toward a real app:
- Firebase email/password registration and login
- Email verification message after registration
- Firestore user profiles and reserved usernames
- Live Firestore text-post feed
- Create and delete your own text posts
- Basic Firestore security rules

## Important before running
This project deliberately does not include Firebase credentials or `firebase_options.dart`. You must connect it to a Firebase project you own. Never share Firebase service-account private keys or passwords in chat.

## Setup checklist
1. Install Flutter SDK and Android Studio (and Xcode on a Mac for iPhone builds).
2. Create a Firebase project at https://console.firebase.google.com/.
3. In Firebase Console, add an Android app using your app's Android application ID. Add an iOS app and Web app too if you plan to launch on those platforms.
4. Install the Firebase command-line tools and FlutterFire CLI:
   - `firebase login`
   - `dart pub global activate flutterfire_cli`
5. From this project folder run:
   - `flutter create .`
   - `flutter pub get`
   - `flutterfire configure`
   This generates `lib/firebase_options.dart` and platform configuration files. Select the Firebase project and the platforms you intend to support.
6. In Firebase Console > Authentication > Sign-in method, enable **Email/Password**.
7. In Firebase Console > Firestore Database, create a database.
8. In Firestore > Rules, publish the contents of `firestore.rules` from this project.
9. Run `flutter run`.

## Current limits
- This milestone supports email/password authentication and text-only posts.
- Photo/video upload, likes, comments, follows, direct messages, notifications, creator payouts and wallet are not implemented yet.
- Email verification is sent, but this starter does not yet block access until the email is verified.
- This is an early development starter, not a production-ready social network. Before public launch, add stronger moderation, abuse reporting, rate limits, account recovery, privacy controls, data deletion/export, testing, monitoring, and a professional security review.
- Firebase costs can apply as usage grows. Configure budget alerts and review Firebase pricing before opening the app to the public.
